PythonicSpeaker Mod for Minetest
==========================
This Mod was developed by iangp

Ian Giestas Pauli
That's my email: iangiestaspauli@hotmail.com
=============================================

This version: v0.1

=======================

License:


Code:
=====

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

http://www.gnu.org/licenses/lgpl-2.1.html

           Authors of python modules used in this mod
==========================================================

                        pyttsx
----------------------------------------------------------
          https://github.com/parente/pyttsx

Copyright (c) 2009, 2013 Peter Parente All rights reserved.

http://creativecommons.org/licenses/BSD/
