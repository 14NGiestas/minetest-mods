Star Wars Mod for Minetest
==========================
This Mod was developed by iangp

Ian Giestas Pauli
That's my email: iangiestaspauli@hotmail.com
==========================

This version: v0.3

==========================

License:

Textures:
=========

(CC BY-NC 4.0)

Code:
=====

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

http://www.gnu.org/licenses/lgpl-2.1.html

Authors of media files used in this mod
=======================================

Sound of the light saber atack (cutted by me and only used in first version):
https://www.freesound.org/people/skytheguy/sounds/186031/

Sound of the light saber atack:
https://www.freesound.org/people/gyzhor/sounds/47125/

Light saber off:
https://www.freesound.org/people/joe93barlow/sounds/78673/

Light saber on:
https://www.freesound.org/people/joe93barlow/sounds/78674/
