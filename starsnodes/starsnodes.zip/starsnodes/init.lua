
local path = minetest.get_modpath("starsnodes")
dofile(path.."/lightsword.lua")
dofile(path.."/ores.lua")
--dofile(path.."/mobs.lua")
--dofile(path.."/sky.lua")
