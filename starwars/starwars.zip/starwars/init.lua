
local path = minetest.get_modpath("starwars")
dofile(path.."/lightsaber.lua")
--dofile(path.."/ores.lua")
--dofile(path.."/mobs.lua")
--dofile(path.."/sky.lua")
