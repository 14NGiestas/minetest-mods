Time Travel Mod for Minetest
==========================
This Mod was created by iangp

Ian Giestas Pauli
============================================
That's my email: iangiestaspauli@hotmail.com
============================================

contribuitors:
=============
>>> rui 
GITHUB: http://github.com/Rui914


License:

Textures:
=========

(CC BY-NC 4.0)
http://creativecommons.org/licenses/by-nc/4.0/

Sounds:
=======

(CC BY-NC 4.0)
http://creativecommons.org/licenses/by-nc/4.0/


Code:
=====

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

http://www.gnu.org/licenses/lgpl-2.1.html
